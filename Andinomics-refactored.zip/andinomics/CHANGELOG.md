# CHANGELOG

Dokumen ini mencatat hasil audit menyeluruh terhadap kode asli Andinomics, bug yang ditemukan, perbaikan yang dilakukan, serta optimasi yang diterapkan pada proses refactor.

---

## [2.0.0] — Refactor Menyeluruh

### 🐛 Bug Kritis yang Ditemukan & Diperbaiki

| # | Bug | File Asli | Dampak | Perbaikan |
|---|---|---|---|---|
| 1 | **Konten "bocor" di luar tag `</html>`.** Sebagian CSS (`.topbar`) dan seluruh section "Riwayat Transaksi" (termasuk tabel, search box) tertulis **setelah** tag penutup `</html>` — di luar struktur dokumen sama sekali. | `index.html` (baris 393–544) | Struktur dokumen tidak valid; browser terpaksa melakukan auto-correction yang tidak konsisten antar-browser; elemen penting berada di luar `<body>` secara semantik. | Seluruh markup disusun ulang menjadi satu struktur `<html><head>…</head><body>…</body></html>` yang valid, tanpa duplikasi. |
| 2 | **Section hero/mini-info rusak & terduplikasi.** Ada `<section class="mini-info">...</section>` dengan isi placeholder `...`, diikuti dua `<div>` yang tidak dibungkus section, lalu judul "Selamat Datang, Andi" dan paragraf **muncul dua kali**, dengan tag `<section>` yang tidak match pasangannya. | `index.html` (baris 97–136) | HTML tidak valid, konten dobel membingungkan pengguna & screen reader. | Digabung menjadi satu `<section class="hero">` bersih berisi judul, deskripsi, dan dua kartu info ringkas. |
| 3 | **CSS rusak: nilai placeholder `...` sebagai deklarasi & properti "menggantung" di luar selector.** `.topbar { ... } width:100%; display:flex; ...` — baris `width:100%;` dst. berada di luar kurung kurawal manapun. | `style.css` (baris 76–100) | CSS tidak valid; sebagian besar properti topbar tidak pernah diterapkan browser sesuai maksud aslinya. | Ditulis ulang sebagai satu blok `.topbar { … }` yang valid dan lengkap. |
| 4 | **Selector terduplikasi dengan nilai bertentangan**: `.chart-box`, `table`, `th`, `td` masing-masing didefinisikan **dua kali** di tempat berbeda dengan nilai warna berbeda (mis. `th` background `#234734` vs `#214131`). | `style.css` | Hasil akhir bergantung urutan CSS (specificity race), sulit dipelihara, membingungkan saat debugging. | Setiap selector kini didefinisikan **sekali saja** di section yang sesuai. |
| 5 | **`Chart.js` dimuat tapi tidak pernah dipakai.** Library di-load via CDN dan `<canvas id="cashflowChart">` sudah ada di HTML, namun **tidak ada satu baris kode pun** di `script.js` yang menginisialisasi chart. | `script.js` | Section "Cash Flow" selalu kosong — fitur utama dashboard tidak berfungsi sama sekali. | Ditambahkan modul `Render.chart()` yang membangun grafik *line chart* pemasukan vs pengeluaran per tanggal, dan diperbarui otomatis setiap transaksi berubah. |
| 6 | **Tombol Edit & Delete rusak secara struktural.** Markup yang di-generate: `<button>Edit<button class="edit-btn" disabled>Edit</button><button><button class="delete-btn" disabled>Hapus</button></button></td>` — nested `<button>` di dalam `<button>` (tidak valid di HTML) dan kedua tombol berstatus `disabled` permanen. | `script.js` (`renderTable`) | Tombol tidak bisa diklik; DOM ambigu karena nested button; fitur edit/hapus transaksi tidak pernah bisa dipakai. | Markup tombol diperbaiki (tidak ada nesting), serta **event handler edit & delete** diimplementasikan penuh dengan konfirmasi sebelum hapus. |
| 7 | **Potensi XSS / DOM Injection.** Data transaksi (`description`, `category`, dll.) disisipkan langsung ke `innerHTML` tanpa sanitasi. Input seperti `<img src=x onerror=alert(1)>` pada kolom "Keterangan" akan tereksekusi sebagai HTML. | `script.js` (`renderTable`) | Celah keamanan XSS — risiko nyata karena data berasal dari input pengguna. | Ditambahkan `Utils.escapeHtml()` yang meng-escape seluruh data dinamis sebelum disisipkan ke `innerHTML`. Sudah diuji: payload HTML kini tampil sebagai teks biasa, bukan dieksekusi. |
| 8 | **Tidak ada validasi input sama sekali.** Deskripsi kosong, nominal `0`/negatif, atau tanggal kosong tetap bisa disimpan. | `script.js` | Data kotor masuk ke dashboard & mengacaukan perhitungan saldo. | Ditambahkan modul `Validation` dengan pesan error inline (`aria-invalid`, `role="alert"`) untuk kolom keterangan, nominal, dan tanggal. Atribut `required`, `min="1"` juga ditambahkan di HTML sebagai lapis pertama. |
| 9 | **Tanggal header di-hardcode statis**: `"Senin, 03 Agustus 2026"` ditulis manual di HTML dan tidak akan pernah berubah. | `index.html` | Informasi tanggal langsung salah begitu halaman dibuka di hari lain. | Tanggal kini dihasilkan otomatis lewat `Intl.DateTimeFormat` di `script.js` saat halaman dimuat. |
| 10 | **Kolom pencarian (`#searchTransaction`) tidak berfungsi** — tidak ada event listener sama sekali, padahal UI-nya sudah ada. | `script.js` | Fitur yang terlihat di UI menyesatkan pengguna karena tidak bekerja. | Ditambahkan `input` event listener yang memfilter tabel transaksi secara real-time. |
| 11 | **Tombol Quick Menu (Tambah Transaksi, Export PDF/Excel, Analytics) tidak punya handler apa pun** — termasuk tidak ber-`type="button"`, berisiko trigger submit form tak sengaja. | `index.html`, `script.js` | Tombol terlihat interaktif tapi tidak melakukan apa-apa saat diklik. | Semua tombol diberi `type="button"`. "Tambah Transaksi" kini scroll otomatis ke form. Export/Analytics (di luar scope refactor ini) menampilkan notifikasi "segera hadir" alih-alih diam saja — lihat *Technical Debt*. |
| 12 | **Gambar logo `assets/logo/Andinomics.jpeg` dirujuk tapi filenya tidak ada** di project (folder `assets/` sama sekali tidak ada di ZIP asli). | `index.html` | Broken image icon selalu tampil di header. | Logo diganti dengan brand mark **inline SVG/icon** (`fa-wallet` dalam kotak gradien) sehingga tidak bergantung pada file eksternal yang hilang. Folder `assets/logo` tetap disediakan untuk logo resmi di masa depan. |
| 13 | **`<label>` pada form tidak terhubung ke `<input>`** (tidak ada atribut `for`/`id` yang dipasangkan secara eksplisit dengan benar untuk semua field, dan kolom pencarian tidak punya label sama sekali). | `index.html` | Screen reader tidak bisa mengumumkan label field dengan benar — masalah aksesibilitas. | Setiap `label` kini memakai `for` yang cocok dengan `id` input-nya; kolom pencarian mendapat `<label class="visually-hidden">`. |

### 🎨 Peningkatan UI/UX

- Desain dirapikan ke gaya **dashboard SaaS modern** (terinspirasi Stripe/Linear/Mekari) tanpa mengubah identitas warna dark-green + orange yang diminta.
- Ditambahkan **design token** (spacing, radius, shadow, type scale) sehingga tampilan konsisten di seluruh halaman.
- Kartu ringkasan (saldo/pemasukan/pengeluaran/transaksi) diberi aksen warna berbeda di tiap kartu untuk mempercepat pemindaian visual (orange/success/danger/blue).
- Status transaksi memakai badge & warna nominal (hijau untuk pemasukan, merah untuk pengeluaran) agar tabel lebih mudah dibaca sekilas.
- Ditambahkan sistem **toast notification** untuk feedback aksi (simpan, edit, hapus, validasi gagal).
- Mode edit transaksi kini punya indikator jelas ("Perbarui Transaksi" + tombol "Batal Edit").
- Empty state tabel & pencarian dibedakan pesannya ("Belum ada transaksi" vs "Tidak ada transaksi yang cocok").

### ⚡ Optimasi Performa

- Atribut `defer` ditambahkan pada `<script>` Chart.js dan `script.js` agar tidak memblokir rendering awal.
- Chart di-*update* (bukan dibuat ulang) saat data berubah — menghindari pembuatan instance Chart.js berulang yang memicu memory leak.
- CSS selector duplikat dihapus, mengurangi ukuran file dan menghindari repaint yang tidak perlu.
- Rendering tabel tetap memakai satu operasi `innerHTML` per render (bukan per baris) untuk meminimalkan reflow.

### ♿ Aksesibilitas

- Kontras warna teks & aksen disesuaikan dengan tema dark agar tetap nyaman dibaca.
- Fokus keyboard terlihat jelas (`:focus-visible`) di seluruh elemen interaktif.
- `aria-live="polite"` pada angka dashboard agar pembaruan otomatis terbaca oleh screen reader.
- `aria-invalid` dan `role="alert"` pada pesan error form.
- `role="img"` + `aria-label` deskriptif pada canvas chart.
- Skip link ("Lompat ke konten utama") ditambahkan untuk pengguna keyboard/screen reader.
- `prefers-reduced-motion` dihormati untuk animasi/transisi.

### 🔒 Keamanan

- Seluruh data dinamis di-escape sebelum disisipkan ke DOM (lihat bug #7) — mitigasi XSS/DOM Injection.
- Validasi input di sisi client untuk mencegah data tidak wajar masuk ke perhitungan saldo.
- Konfirmasi (`window.confirm`) sebelum menghapus transaksi, mencegah penghapusan tidak sengaja.

### 📁 File yang Diubah

- `index.html` — ditulis ulang total (struktur semantic, form dengan label & validasi, tanpa konten di luar `</html>`).
- `style.css` — ditulis ulang total (design token, section terorganisir, tanpa duplikasi selector).
- `script.js` — ditulis ulang total (arsitektur modular: State, DOM cache, Utils, Validation, Render, Toast, Event Handlers, Init).
- `README.md`, `CHANGELOG.md`, `PROJECT_REVIEW.md`, `ARCHITECTURE.md` — baru dibuat.

### ✅ Kompatibilitas

- Tidak ada perubahan framework/tooling — tetap HTML5 + CSS3 + Vanilla JS + Chart.js.
- Tidak memerlukan proses build apa pun — tetap kompatibel 100% dengan **GitHub Pages**.
- Semua fitur lama yang berfungsi tetap dipertahankan; fitur yang sebelumnya *terlihat* tapi rusak (edit, delete, search, chart, tanggal) kini benar-benar berfungsi.
