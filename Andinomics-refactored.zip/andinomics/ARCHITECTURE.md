# ARCHITECTURE — Andinomics Smart Financial Dashboard

Dokumen ini menjelaskan struktur folder, hubungan antar file, dan alur kerja aplikasi agar developer lain dapat memahami project dengan cepat.

---

## 1. Struktur Folder

```
/
├── index.html          Struktur halaman (semantic HTML5, satu halaman/SPA sederhana)
├── style.css             Seluruh styling, disusun per section + design tokens
├── script.js              Seluruh logika aplikasi (IIFE tunggal, tanpa dependency build)
├── assets/
│   ├── logo/              Tempat file logo resmi (belum diisi — lihat README)
│   ├── images/            Gambar pendukung lain (kosong, disiapkan untuk masa depan)
│   └── icons/             Ikon kustom di luar Font Awesome (kosong, disiapkan untuk masa depan)
├── README.md              Panduan menjalankan & deploy project
├── CHANGELOG.md           Riwayat bug & perbaikan hasil audit
├── PROJECT_REVIEW.md      Penilaian kualitas & rekomendasi pengembangan
└── ARCHITECTURE.md        Dokumen ini
```

## 2. Hubungan Antar File

```
index.html
 ├─ <link> style.css              (styling seluruh halaman)
 ├─ <script defer> Chart.js (CDN) (dependency eksternal untuk grafik)
 └─ <script defer> script.js      (logika aplikasi, dimuat setelah HTML di-parse)
```

`script.js` **tidak memodifikasi** `style.css` secara langsung, tapi membaca beberapa CSS custom property (`--success`, `--danger`, `--text-muted`) lewat `getComputedStyle()` agar warna chart selalu sinkron dengan tema — jadi mengubah warna tema di `:root` pada `style.css` otomatis mengubah warna chart juga, tanpa perlu menyentuh JavaScript.

## 3. Alur Aplikasi (Application Flow)

```
┌─────────────────────┐
│  DOMContentLoaded    │
└──────────┬───────────┘
           ▼
      init()
   ├─ set tanggal hari ini (header)
   ├─ set tahun footer
   ├─ set default tanggal form = hari ini
   ├─ pasang semua event listener
   └─ Render.all()  ──► render dashboard, tabel, & chart kondisi awal (kosong)

┌────────────────────────────┐
│ User mengisi & submit form  │
└──────────────┬──────────────┘
               ▼
     handleFormSubmit()
   ├─ Validation.validate()  ─► gagal? tampilkan error inline + toast, STOP
   ├─ sukses & mode tambah   ─► transactions.push(...)
   ├─ sukses & mode edit     ─► transactions[index] = {...}
   ├─ resetFormToCreateMode()
   └─ Render.all()  ─► dashboard, tabel, dan chart ter-update otomatis

┌───────────────────────────┐
│ User klik Edit / Hapus     │
│ (delegasi event di tbody)  │
└──────────────┬─────────────┘
               ▼
     handleTableClick()
   ├─ action="edit"   ─► enterEditMode(id): isi ulang form + ubah label tombol
   └─ action="delete" ─► confirm() → transactions = filter(...) → Render.all()

┌───────────────────────────┐
│ User mengetik di kolom cari │
└──────────────┬─────────────┘
               ▼
     handleSearchInput()
   └─ Render.table(keyword)  ─► hanya tabel yang difilter & digambar ulang
```

## 4. Struktur JavaScript (`script.js`)

File dibungkus dalam satu **IIFE** (`(function () { "use strict"; ... })()`) untuk menghindari polusi variabel global, dan dibagi menjadi 8 modul dengan tanggung jawab jelas:

| Modul | Tanggung Jawab |
|---|---|
| **1. State** | Menyimpan data aplikasi: array `transactions`, `editingId`, instance `cashflowChart`. Satu-satunya "sumber kebenaran" data. |
| **2. DOM cache** | Objek `dom` — seluruh referensi elemen DOM diambil sekali di awal, dipakai ulang di semua fungsi (menghindari `getElementById` berulang). |
| **3. Utils** | Fungsi murni tanpa efek samping ke state: format Rupiah, format tanggal, `escapeHtml` (anti-XSS), `generateId`. |
| **4. Validation** | Objek `Validation` — validasi form + menyimpan & menampilkan pesan error per field. |
| **5. Render** | Tiga fungsi render (`dashboard`, `table`, `chart`) + `all()` sebagai shortcut memanggil ketiganya. Modul ini **hanya membaca** `transactions`, tidak pernah mengubahnya — memisahkan "read" dari "write" (mirip prinsip *unidirectional data flow*). |
| **6. Toast** | `showToast()` — notifikasi non-blocking untuk feedback aksi pengguna. |
| **7. Event Handlers** | Semua fungsi `handleXxx()` — satu-satunya tempat yang boleh **mengubah** `transactions` (menulis state). |
| **8. Init** | `init()` — titik masuk aplikasi, dipanggil saat `DOMContentLoaded`. |

### Prinsip yang diterapkan

- **DRY** — logika format Rupiah/tanggal, sanitasi, dan render hanya ada di satu tempat, dipakai ulang di banyak alur (form, tabel, chart).
- **Single Responsibility** — tiap modul punya satu tugas: `Validation` tidak tahu cara render, `Render` tidak tahu cara validasi.
- **Predictable state flow** — hanya *event handlers* yang boleh menulis ke `transactions`; setelah itu selalu memanggil `Render.all()` sehingga UI selalu konsisten dengan state.

## 5. Struktur CSS (`style.css`)

CSS disusun dalam 13 section berurutan sesuai standar yang diminta:

1. Root (design tokens: warna, spacing, radius, shadow, tipografi)
2. Reset
3. Typography
4. Layout
5. Header
6. Hero
7. Dashboard / Card
8. Buttons (global)
9. Chart
10. Form
11. Table / History
12. Footer
13. Responsive

Setiap section diberi komentar penanda (`/* ===== NAMA SECTION ===== */`) agar mudah dicari. Semua nilai warna, spacing, radius, dan shadow **wajib** memakai CSS custom property dari section Root — tidak ada nilai hex atau px "hardcoded" di section lain, kecuali untuk kasus spesifik (mis. lebar minimum tabel) yang memang unik untuk komponen tersebut.

## 6. Struktur HTML (`index.html`)

```
<html>
 └─ <head>          meta, font, favicon, CDN, link ke style.css
 └─ <body>
     ├─ <a class="skip-link">      aksesibilitas: lompat ke konten utama
     ├─ <header class="topbar">    brand + tanggal + profil
     ├─ <main id="main-content">
     │    ├─ <section class="hero">              sambutan + info ringkas
     │    ├─ <section class="dashboard">          4 kartu ringkasan
     │    ├─ <nav class="quick-menu">              4 tombol aksi cepat
     │    ├─ <section class="chart-box">           grafik cash flow
     │    ├─ <section class="transaction-form">    form tambah/edit transaksi
     │    └─ <section class="history-section">     pencarian + tabel riwayat
     ├─ <footer>
     └─ <div class="toast">         notifikasi (di luar main, fixed position)
```

Satu `<main>`, tanpa nesting, tanpa duplikasi tag — setiap `<section>` memiliki `aria-label`/`aria-labelledby` agar struktur juga terbaca jelas oleh assistive technology.

## 7. Menambah Fitur Baru Tanpa Refactor Besar

- **Local Storage** → cukup tambahkan pemanggilan `localStorage.setItem` di akhir setiap *event handler* yang mengubah `transactions` (add/edit/delete), dan `localStorage.getItem` di `init()` sebelum `Render.all()`.
- **Export PDF/Excel** → ganti isi `if (action === "export-pdf")` pada `handleQuickMenuClick` dengan pemanggilan library export, menggunakan `transactions` yang sudah tersedia di module State.
- **Dark/Light mode** → tambahkan `[data-theme="light"] { --bg: ...; }` di `style.css`, lalu toggle atribut `data-theme` pada `<html>` lewat JS.
- **Analytics tambahan** → tambahkan modul baru di `Render` (mis. `Render.categoryBreakdown()`) yang membaca `transactions` — tidak perlu mengubah modul lain.
